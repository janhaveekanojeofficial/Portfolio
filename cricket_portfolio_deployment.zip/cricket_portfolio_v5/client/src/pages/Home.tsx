import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import ImageCarousel from "@/components/ImageCarousel";
import { ExternalLink, Trophy, Zap } from "lucide-react";
import { useState } from "react";

/**
 * Modern Athlete Theme - Home Page
 * Charcoal background with electric teal accents
 * Showcases cricket achievements and career progression
 */
export default function Home() {
  // The userAuth hooks provides authentication state
  // To implement login/logout functionality, simply call logout() or redirect to getLoginUrl()
  let { user, loading, error, isAuthenticated, logout } = useAuth();

  const [mediaLink] = useState("https://drive.google.com/drive/folders/1hAcLmGRwqqtDK8gl_7OYKgmEP0la-2-n?usp=drive_link");

  const achievements = [
    {
      year: "8th Standard",
      title: "The Start..",
      highlights: [
        "Played U-15 and U-16 VCA (Vidharbha Cricket Association) tournaments",
        "Player of the Tournament in U-16 School VCA Tournament",
        "Highest Wicket Taker and Run Scorer",
        "Man of the Match in U-16 VCA Club Tournament",
        "District Level Champion in High Jump",
      ],
    },
    {
      year: "9th Standard",
      title: "Leadership & Excellence",
      highlights: [
        "Represented State in High Jump (Satara, Maharashtra)",
        "Captain of School Cricket Team (8th to 10th)",
        "Interschool Tournament Winner",
        "2 Man of the Match awards in the same tournament",
        "District Sports Organisation Trophy Winner",
        "Represented District (Nagpur) as Captain",
        "Played Mumbai Indians Juniors Finals as Captain",
        "2 Man of the Match in Mumbai Indians Juniors Trophy",
      ],
    },
    {
      year: "10th Standard",
      title: "National Recognition",
      highlights: [
        "Represented Nationals in High Jump at Vishakapatnam",
        "Played VCA Leagues as Vice-Captain",
        "Net Bowler in IPL (Indian Premier League) - 1st & 2nd Year",
      ],
    },
    {
      year: "3rd Year & Beyond",
      title: "Professional Cricketer",
      highlights: [
        "Net Bowler in KPL (Karnataka Premier League)",
        "Represented University in Chennai from BCU University Bangalore",
        "Currently Player in KSCA League",
        "2nd Highest Wicket Taker in Team with 12 Wickets in 6 Matches",
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="border-b border-border bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container flex items-center justify-between h-16">
          <div className="text-2xl font-semibold">
            <span className="text-foreground">Cricket</span>
            <span className="text-accent"> Portfolio</span>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-background via-background to-secondary/20" style={{
        backgroundImage: 'url(/images/cricket-bg.jpg)',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed'
      }}>
        {/* Faded blur overlay */}
        <div className="absolute inset-0" style={{
          background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.85) 0%, rgba(245, 245, 220, 0.8) 100%)',
          backdropFilter: 'blur(8px)'
        }}></div>
        <div className="container py-20 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            {/* Profile Image */}
            <div className="flex justify-center">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-br from-accent to-accent/30 rounded-lg blur-2xl" style={{opacity: 0.3}}></div>
                <img
                  src="/images/profile-actual.jpg"
                  alt="Palash Ajay Kanoje - Cricket Player"
                  className="relative w-full max-w-lg aspect-square object-cover rounded-lg border-2 border-accent shadow-2xl"
                />
              </div>
            </div>

            {/* Hero Content */}
            <div className="space-y-8">
              <div className="space-y-4">
                <h1 className="text-5xl md:text-6xl font-semibold leading-tight">
                  <span className="text-accent">Palash Ajay Kanoje</span>
                  <br />
                  <span className="font-normal">Professional Cricket Player</span>
                </h1>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  From school captain to IPL net bowler, showcasing a journey of excellence in cricket and athletics. Currently competing in KSCA League with consistent high-performance records.
                </p>
              </div>

              {/* Player Information as Text */}
              <div className="grid grid-cols-2 gap-6 md:grid-cols-4 text-base mb-8">
                <div>
                  <div className="text-muted-foreground text-sm mb-1">Location</div>
                  <div className="font-semibold text-foreground text-lg">Bangalore, Karnataka</div>
                </div>
                <div>
                  <div className="text-muted-foreground text-sm mb-1">Playing Role</div>
                  <div className="font-semibold text-foreground text-lg">All Rounder</div>
                </div>
                <div>
                  <div className="text-muted-foreground text-sm mb-1">Batting Style</div>
                  <div className="font-semibold text-foreground text-lg">RHB</div>
                </div>
                <div>
                  <div className="text-muted-foreground text-sm mb-1">Bowling Style</div>
                  <div className="font-semibold text-foreground text-lg">Right Arm Off Break</div>
                </div>
              </div>

              {/* Key Stats */}
              <div className="grid grid-cols-3 gap-4">
                <div className="inline-flex items-center justify-center rounded-full px-4 py-2 border border-accent" style={{backgroundColor: 'rgba(212, 175, 55, 0.1)'}}>
                  <div className="text-center">
                    <div className="stat-badge">21</div>
                    <div className="text-xs text-muted-foreground mt-1">Age</div>
                  </div>
                </div>
                <div className="inline-flex items-center justify-center rounded-full px-4 py-2 border border-accent" style={{backgroundColor: 'rgba(212, 175, 55, 0.1)'}}>
                  <div className="text-center">
                    <div className="stat-badge">10+</div>
                    <div className="text-xs text-muted-foreground mt-1">Years Experience</div>
                  </div>
                </div>
                <div className="inline-flex items-center justify-center rounded-full px-4 py-2 border border-accent" style={{backgroundColor: 'rgba(212, 175, 55, 0.1)'}}>
                  <div className="text-center">
                    <div className="stat-badge">KSCA</div>
                    <div className="text-xs text-muted-foreground mt-1">Current League</div>
                  </div>
                </div>
              </div>

              {/* CTA Button */}
              <div className="flex gap-4 pt-4">
                <a
                  href={mediaLink}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Button
                    size="lg"
                    className="bg-accent text-accent-foreground hover:bg-accent/90 font-semibold"
                  >
                    <Zap size={20} />
                    View Media Gallery
                  </Button>
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Accent Divider */}
        <div className="accent-divider"></div>
      </section>

      {/* Career Timeline Section */}
      <section className="py-20 bg-background">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-5xl md:text-6xl font-semibold mb-4">Career Journey</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              A progressive path from school cricket to professional leagues, marked by consistent excellence and leadership.
            </p>
          </div>

          {/* Timeline */}
          <div className="space-y-8">
            {achievements.map((period, index) => (
              <div key={index} className="relative">
                {/* Timeline Marker */}
                <div className="flex items-start gap-6">
                  <div className="flex flex-col items-center">
                    <div className="w-12 h-12 rounded-full bg-accent flex items-center justify-center flex-shrink-0 border-2 border-background shadow-lg">
                      <Trophy size={24} className="text-accent-foreground" />
                    </div>
                    {index < achievements.length - 1 && (
                      <div className="w-1 h-24 bg-gradient-to-b from-accent to-accent/20 mt-4"></div>
                    )}
                  </div>

                  {/* Achievement Card */}
                  <div className="achievement-card flex-1 mt-2">
                    <div className="mb-4">
                      <span className="inline-block px-3 py-1 rounded-full border border-accent text-accent text-sm font-semibold mb-2" style={{backgroundColor: 'rgba(212, 175, 55, 0.1)'}}>
                        {period.year}
                      </span>
                      <h3 className="text-2xl font-normal text-accent mt-2">{period.title}</h3>
                    </div>

                    <ul className="space-y-2">
                      {period.highlights.map((highlight, hIndex) => (
                        <li key={hIndex} className="flex items-start gap-3 text-foreground/90">
                          <span className="text-accent font-bold mt-1">•</span>
                          <span>{highlight}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-20 bg-background border-t border-border">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">Performance Gallery</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Moments of excellence captured during tournaments, matches, and training sessions.
            </p>
          </div>

          <ImageCarousel
            images={[
              "/images/gallery-1.jpg",
              "/images/gallery-2.jpg",
              "/images/new-gallery-1.jpeg",
              "/images/new-gallery-2.jpeg",
              "/images/new-gallery-3.jpeg",
            ]}
          />
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="py-20 bg-gradient-to-r from-secondary to-secondary/50 border-t border-border">
        <div className="container text-center">
          <h2 className="text-4xl font-bold mb-6">Know More about Me</h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Explore my complete portfolio, watch performance videos, and view match highlights and training sessions.
          </p>
          <a
            href={mediaLink}
            target="_blank"
            rel="noopener noreferrer"
          >
            <Button
              size="lg"
              className="bg-accent text-accent-foreground hover:bg-accent/90 font-semibold"
            >
              <ExternalLink size={20} />
              Visit Media Gallery
            </Button>
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-background/50 py-8">
        <div className="container text-center text-muted-foreground">
          <p>&copy; 2026 Cricket Portfolio. All rights reserved.</p>
          <p className="text-sm mt-2">Professional athlete | Passionate about excellence</p>
        </div>
      </footer>
    </div>
  );
}
